/* TRfilm.Net source module for Kinetiq / Synthetiq contract v4.
 * Public catalogue metadata only; direct playback is accepted ONLY when
 * the selected title page exposes a real HTTPS HLS/MP4 URL. A YouTube
 * trailer or HTML embed is never presented as a full movie stream.
 * No Node.js, DOM, remote script execution, or DRM interception.
 */
(function () {
  'use strict';

  var BASE = 'https://www.trfilm.net';
  var UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';
  var CACHE_MS = 45000;
  var cache = Object.create(null);
  var cacheOrder = [];
  var FEEDS = {
    latest: { path: '/', title: 'Yeni Eklenen Filmler' },
    action: { path: '/aksiyon-filmleri-izle/', title: 'Aksiyon' },
    comedy: { path: '/komedi-filmleri-izle/', title: 'Komedi' },
    series: { path: '/diziler/', title: 'Diziler' }
  };

  function decodeEntities(input) {
    return String(input == null ? '' : input).replace(/&(#x[0-9a-f]+|#\d+|[a-z][a-z0-9]+);/gi, function (_, entity) {
      var names = { amp: '&', quot: '"', apos: "'", nbsp: ' ', lt: '<', gt: '>', hellip: '…', ndash: '–', mdash: '—', rsquo: '’', lsquo: '‘', ldquo: '“', rdquo: '”', bull: '•', copy: '©', ccedil: 'ç', Ccedil: 'Ç', ouml: 'ö', Ouml: 'Ö', uuml: 'ü', Uuml: 'Ü', aring: 'å', szlig: 'ß' };
      if (entity.charAt(0) === '#') {
        var number = /^#x/i.test(entity) ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
        if (number > 0 && number <= 1114111 && !(number >= 55296 && number <= 57343)) {
          try { return String.fromCodePoint(number); } catch (_) {}
        }
        return '';
      }
      return Object.prototype.hasOwnProperty.call(names, entity) ? names[entity] : (names[entity.toLowerCase()] || '&' + entity + ';');
    });
  }

  function stripHTML(html) {
    return decodeEntities(String(html == null ? '' : html)
      .replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, ' ')
      .replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi, ' ')
      .replace(/<br\s*\/?\s*>/gi, ' ')
      .replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();
  }

  function attr(tag, name) {
    var escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    var m = String(tag).match(new RegExp('(?:^|\\s)' + escaped + '\\s*=\\s*(["\'])([\\s\\S]*?)\\1', 'i'));
    return m ? decodeEntities(m[2]) : '';
  }

  function canonical(value) {
    var s = decodeEntities(String(value == null ? '' : value).trim()).replace(/\\\//g, '/');
    if (!s || /[\r\n\x00-\x1f]/.test(s)) return '';
    if (s.indexOf('//') === 0) s = 'https:' + s;
    if (s.charAt(0) === '/') s = BASE + s;
    if (!/^https:\/\//i.test(s)) return '';
    var m = s.match(/^https:\/\/([^\/?#]+)(\/[^#]*)?/i);
    if (!m || !/^(?:www\.)?trfilm\.net$/i.test(m[1])) return '';
    return BASE + (m[2] || '/');
  }

  function posterURL(value) {
    var s = decodeEntities(String(value == null ? '' : value).trim());
    if (!s || /[\x00-\x1f]/.test(s)) return '';
    if (s.indexOf('//') === 0) s = 'https:' + s;
    if (s.charAt(0) === '/') s = BASE + s;
    return /^https:\/\/(?:www\.)?trfilm\.net\//i.test(s) ? s : '';
  }

  function unique(list, limit) {
    var seen = Object.create(null), out = [];
    for (var i = 0; i < list.length && out.length < limit; i++) {
      var e = list[i];
      if (!e || !e.href || seen[e.href]) continue;
      seen[e.href] = true;
      out.push(e);
    }
    return out;
  }

  async function getHTML(url) {
    var safeURL = canonical(url);
    if (!safeURL) throw new Error('TRfilm: rejected non-site URL');
    var entry = cache[safeURL];
    if (entry && Date.now() - entry.at < CACHE_MS) return entry.html;
    var response = await fetchv2(safeURL, {
      'User-Agent': UA,
      'Accept': 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.5',
      'Referer': BASE + '/'
    }, 'GET', null, { timeoutMs: 14000 });
    var status = Number(response && (response.status || response.statusCode)) || 0;
    var body = '';
    if (response && typeof response.text === 'function') body = await response.text();
    else if (response && typeof response.body === 'string') body = response.body;
    if (status < 200 || status >= 300) throw new Error('TRfilm catalogue returned HTTP ' + status);
    body = String(body == null ? '' : body);
    if (!body || !/(?:film-box|film-bilgileri|<html|<body)/i.test(body)) {
      throw new Error('TRfilm returned no readable HTML');
    }
    if (body.length > 1600000) body = body.slice(0, 1600000);
    cache[safeURL] = { at: Date.now(), html: body };
    cacheOrder.push(safeURL);
    if (cacheOrder.length > 6) delete cache[cacheOrder.shift()];
    return body;
  }

  function parseCard(segment) {
    var media = segment.match(/<div\s+class\s*=\s*["'][^"']*\bmovie-box\b[^"']*["'][^>]*>([\s\S]*)/i);
    var src = media ? media[1] : segment;
    var href = (src.match(/<a\s+[^>]*href\s*=\s*(["'])([^"']+)\1/i) || [])[2] || '';
    var name = src.match(/<div\s+class\s*=\s*["'][^"']*\bname\b[^"']*["'][^>]*>[\s\S]*?<a\b([^>]*)>([\s\S]*?)<\/a>/i);
    var imageTag = src.match(/<img\b[^>]*>/i);
    var image = imageTag ? (attr(imageTag[0], 'data-src') || attr(imageTag[0], 'src')) : '';
    var title = name ? (attr(name[1], 'title') || stripHTML(name[2])) : (imageTag ? attr(imageTag[0], 'alt') : '');
    var description = (src.match(/<p\s+class\s*=\s*["'][^"']*\bstory\b[^"']*["'][^>]*>([\s\S]*?)<\/p>/i) || [])[1] || '';
    var year = (src.match(/<div\s+class\s*=\s*["'][^"']*\bcategory\b[^"']*["'][^>]*>\s*(\d{4})/i) || [])[1] || '';
    var link = canonical(href);
    var cleanedTitle = stripHTML(title).slice(0,240);
    if (!link || !cleanedTitle) return null;
    return { id: link, href: link, title: cleanedTitle, image: posterURL(image), description: stripHTML(description).slice(0,900), year: year };
  }

  function parseCards(html, max) {
    var markers = [], re = /<div\s+class\s*=\s*["'][^"']*\bfilm-box\b[^"']*["'][^>]*>/gi;
    var m, output = [];
    while ((m = re.exec(html)) !== null) {
      markers.push(m.index);
      if (markers.length >= 180) break;
    }
    for (var i = 0; i < markers.length && output.length < (max || 50); i++) {
      var chunk = html.slice(markers[i], markers[i + 1] || html.length);
      var card = parseCard(chunk);
      if (card) output.push(card);
    }
    return unique(output, max || 50);
  }

  function meta(html, key) {
    var re = /<meta\b[^>]*>/gi, tag;
    while ((tag = re.exec(html)) !== null) {
      var name = attr(tag[0], 'property') || attr(tag[0], 'name');
      if (name.toLowerCase() === key.toLowerCase()) return attr(tag[0], 'content');
    }
    return '';
  }

  function detailFromHTML(html, href) {
    var blockStart = html.search(/class\s*=\s*["']film-bilgileri["']/i);
    var blockEnd = blockStart >= 0 ? html.indexOf('class="home-con"', blockStart) : -1;
    var block = blockStart >= 0 ? html.slice(blockStart, blockEnd > blockStart ? blockEnd : blockStart + 50000) : html;
    var h1 = (block.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i) || [])[1];
    var d = (block.match(/<div\s+class\s*=\s*["']description["'][^>]*>([\s\S]*?)<\/div>/i) || [])[1] || '';
    var img = (block.match(/<img\b[^>]*>/i) || [])[0] || '';
    var title = stripHTML(h1 || meta(html, 'og:title') || 'Untitled film').replace(/\s*\|\s*TRfilm\.Net\s*$/i, '');
    var image = posterURL(meta(html, 'og:image')) || posterURL(attr(img, 'src'));
    var synopsis = stripHTML(d).slice(0,3500);
    var year = (block.match(/class\s*=\s*["']release["'][\s\S]*?(\d{4})/i) || [])[1] || '';
    return { id: href, href: href, title: title, image: image, description: synopsis, year: year };
  }

  function directMediaURLs(html) {
    // Only inspect the film's player panel. Links in the trailer iframe,
    // related posts, comments, inline analytics and ads are not streams.
    var start = html.search(/<div\s+class\s*=\s*["'][^"']*\bvideo-content\b/i);
    if (start < 0) return [];
    var next = html.indexOf('class="film-bilgileri"', start);
    var panel = html.slice(start, next > start ? Math.min(next, start + 80000) : start + 20000);
    // Explicit HTML5 video sources and direct URLs in simple player config.
    var candidates = [];
    var tag, re = /<(?:video|source)\b[^>]*>/gi;
    while ((tag = re.exec(panel)) !== null) {
      var src = attr(tag[0], 'src') || attr(tag[0], 'data-src');
      if (src) candidates.push(src);
    }
    var scriptSources = /(?:file|src|source|hls|videoUrl|playlistUrl)\s*[:=]\s*["']([^"']+\.(?:m3u8|mp4|m4v)(?:\?[^"']*)?)["']/gi;
    var match;
    while ((match = scriptSources.exec(panel)) !== null) candidates.push(match[1]);
    var out = [], seen = Object.create(null);
    for (var i = 0; i < candidates.length && out.length < 5; i++) {
      var address = decodeEntities(String(candidates[i]).replace(/\\\//g, '/'));
      if (address.indexOf('//') === 0) address = 'https:' + address;
      if (!/^https:\/\//i.test(address) || !/\.(?:m3u8|mp4|m4v)(?:\?|$)/i.test(address)) continue;
      var host = (address.match(/^https:\/\/([^\/:?#]+)/i) || [])[1] || '';
      if (!host || /(?:^|\.)(?:localhost|youtube\.com|youtu\.be|googlevideo\.com)$/i.test(host) ||
          /^(?:127\.|10\.|192\.168\.|169\.254\.|0\.)/.test(host)) continue;
      if (seen[address]) continue;
      seen[address] = true;
      out.push(address);
    }
    return out;
  }

  function feedURL(id, page) {
    var feed = FEEDS[id];
    if (!feed) return '';
    var num = Math.min(80, Math.max(1, Math.floor(Number(page) || 1)));
    if (num === 1) return BASE + feed.path;
    return BASE + (id === 'latest' ? '/page/' + num + '/' : feed.path + 'page/' + num + '/');
  }

  async function feedCards(id, page, limit) {
    var url = feedURL(id, page);
    if (!url) return [];
    try { return parseCards(await getHTML(url), limit || 40); }
    catch (error) { if (page === 1) throw error; return []; }
  }

  async function searchResults(query) {
    var q = String(query == null ? '' : query).trim().slice(0,120);
    if (!q) return [];
    return parseCards(await getHTML(BASE + '/?s=' + encodeURIComponent(q)), 60);
  }

  async function extractDetails(href) {
    var link = canonical(href);
    if (!link) throw new Error('TRfilm: invalid title URL');
    return detailFromHTML(await getHTML(link), link);
  }

  async function extractEpisodes(href) {
    var link = canonical(href);
    if (!link) return [];
    // The title page represents one film. Don't manufacture numbered seasons
    // or episode links for series when the site doesn't publish them.
    var html = await getHTML(link);
    if (!/class\s*=\s*["']film-bilgileri["']/i.test(html)) return [];
    return [{ id: link, number: 1, title: 'Film', href: link, subAvailable: true, dubAvailable: false }];
  }

  async function extractStreamUrl(href, language) {
    var link = canonical(href);
    if (!link) throw new Error('TRfilm: invalid film URL');
    var html = await getHTML(link);
    var direct = directMediaURLs(html);
    if (direct.length) {
      var servers = direct.map(function (url, i) {
        return { label: 'Direct ' + (i + 1), url: url, streamType: /\.m3u8(?:\?|$)/i.test(url) ? 'hls' : 'mp4', lang: 'sub', headers: { Referer: BASE + '/' } };
      });
      return { url: servers[0].url, streamType: servers[0].streamType, lang: 'sub', servers: servers, streams: servers.map(function (s) { return { url: s.url, label: s.label, streamType: s.streamType, headers: s.headers }; }), subtitles: [] };
    }
    if (/youtube\.com\/embed\/|youtu\.be\//i.test(html.slice(0, 100000))) {
      throw new Error('TRfilm.Net only exposes a YouTube trailer or clip for this title; no full-film MP4 or HLS stream is published on the page. The trailer is not a playable movie stream.');
    }
    throw new Error('TRfilm.Net does not expose a verified MP4 or HLS stream for this film. This module cannot play HTML-only embeds or invent video URLs.');
  }

  async function discoveryHome() {
    var names = ['latest', 'action', 'comedy', 'series'];
    // Parallel source-owned feeds, bounded by caps.maxConcurrentRequests.
    // A single unavailable category must not hide the other shelves.
    var pages = await Promise.all(names.map(function (id, i) {
      return feedCards(id, 1, i === 0 ? 24 : 18).catch(function () { return []; });
    }));
    var sections = [];
    for (var i = 0; i < names.length; i++) {
      if (!pages[i].length) continue;
      sections.push({
        id: 'trfilm-' + names[i],
        title: FEEDS[names[i]].title,
        style: 'poster',
        items: pages[i],
        viewAll: { mode: 'feed', feedId: names[i] }
      });
    }
    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    var id = String(feedId || '');
    var num = Math.min(80, Math.max(1, Math.floor(Number(page) || 1)));
    if (!FEEDS[id]) return { items: [], page: num, hasMore: false };
    var cards = await feedCards(id, num, 60);
    return { items: cards, page: num, hasMore: cards.length >= 12 && num < 80 };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
