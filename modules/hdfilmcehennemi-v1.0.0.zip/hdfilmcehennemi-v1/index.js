(function () {
  'use strict';
  // Synthetiq Player contract V3; no imports, proxy, remote JavaScript, eval, Node APIs or DOM.
  var BASE = 'https://www.hdfilmcehennemi.nl';
  var EMBED = 'https://hdfilmcehennemi.mobi';
  var UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36';
  var HEADERS = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
    'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.6',
    'Referer': BASE + '/'
  };

  function mix(a, b) {
    var result = {}, key;
    for (key in a) if (Object.prototype.hasOwnProperty.call(a, key)) result[key] = a[key];
    if (b) for (key in b) if (Object.prototype.hasOwnProperty.call(b, key)) result[key] = b[key];
    return result;
  }
  function entity(s) {
    return String(s || '').replace(/&amp;/g, '&').replace(/&quot;/g, '"')
      .replace(/&#39;|&#x27;|&apos;/gi, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&nbsp;/g, ' ').replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(+n); })
      .replace(/&#x([a-f\d]+);/gi, function (_, n) { return String.fromCharCode(parseInt(n, 16)); });
  }
  function clean(s) {
    return entity(String(s || '').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ').trim());
  }
  function attr(tag, name) {
    var re = new RegExp('\\b' + name + '\\s*=\\s*(["\\\'])([\\s\\S]*?)\\1', 'i');
    var m = String(tag || '').match(re);
    return m ? entity(m[2]) : '';
  }
  function unescapeJs(s) {
    return entity(String(s || '').replace(/\\\//g, '/').replace(/\\u0026/gi, '&')
      .replace(/\\u003d/gi, '=').replace(/\\u002f/gi, '/')
      .replace(/\\x2f/gi, '/').replace(/\\x3a/gi, ':').replace(/\\x26/gi, '&'));
  }
  function origin(u) {
    var m = String(u || '').match(/^(https?:\/\/[^/?#]+)/i);
    return m ? m[1] : '';
  }
  function abs(s, parent) {
    s = unescapeJs(String(s || '').trim());
    parent = parent || BASE + '/';
    if (!s || /^(?:data|javascript|blob):/i.test(s)) return '';
    if (/^https?:\/\//i.test(s)) return s;
    if (s.slice(0, 2) === '//') return 'https:' + s;
    var host = origin(parent);
    if (!host) return '';
    if (s.charAt(0) === '/') return host + s;
    var path = parent.slice(host.length).replace(/[?#][\s\S]*$/, '');
    if (path.slice(-1) !== '/') path = path.replace(/\/[^/]*$/, '/');
    while (s.slice(0, 3) === '../') { s = s.slice(3); path = path.replace(/[^/]+\/$/, ''); }
    return host + path + s.replace(/^\.\//, '');
  }
  function acceptablePage(s) {
    return !/(?:just a moment|cf-browser-verification|<title>\s*attention required|checking your browser before accessing|\baccess denied\b)/i.test(s);
  }
  function normalizeBody(res) {
    if (res == null) return Promise.resolve('');
    if (typeof res === 'string') return Promise.resolve(res);
    if (typeof res.text === 'function') {
      try { return Promise.resolve(res.text()).then(function (t) { return typeof t === 'string' ? t : JSON.stringify(t); }); }
      catch (_) { /* try body */ }
    }
    if (typeof res.body === 'string') return Promise.resolve(res.body);
    if (res.body && typeof res.body === 'object') return Promise.resolve(JSON.stringify(res.body));
    if (typeof res.json === 'function') {
      return Promise.resolve(res.json()).then(function (v) { return typeof v === 'string' ? v : JSON.stringify(v); });
    }
    return Promise.resolve('');
  }
  function doFetch(url, headers, method, body) {
    var h = mix(HEADERS, headers || {});
    method = method || 'GET';
    if (typeof fetchv2 === 'function') return fetchv2(url, h, method, body == null ? null : body);
    if (typeof fetch === 'function') {
      var options = { method: method, headers: h };
      if (body != null && method !== 'GET') options.body = body;
      return fetch(url, options);
    }
    throw new Error('Synthetiq HTTP unavailable: fetchv2/fetch not provided');
  }
  function request(url, headers, method, body) {
    return Promise.resolve(doFetch(url, headers, method, body)).then(function (res) {
      return normalizeBody(res).then(function (value) {
        var status = Number(res && (res.status || res.statusCode) || 200);
        if (status >= 400) throw new Error('HTTP ' + status + ' fetching ' + url);
        return { text: String(value || ''), headers: (res && res.headers) || {}, status: status, url: (res && res.url) || url };
      });
    });
  }
  function parseJson(s) {
    try { return JSON.parse(s); } catch (_) { return null; }
  }
  function htmlFromData(s) {
    var json = parseJson(s);
    if (!json) return s;
    var item = json.html || (json.data && (json.data.html || json.data)) || '';
    if (typeof item === 'string') return item;
    return s;
  }
  function fetchPage(url) {
    // The site offers a router JSON response alongside normal HTML pages.
    var router = url + (url.indexOf('?') === -1 ? '?router=1' : '&router=1');
    var routerHeaders = {
      'X-Requested-With': 'fetch',
      'Mofycore-Router-Prefetch': 'false',
      'Accept': 'application/json, text/html;q=0.9',
      'Referer': url
    };
    return request(router, routerHeaders).then(function (r) {
      var html = htmlFromData(r.text);
      if (!acceptablePage(html) || html.length < 100) throw new Error('Router response empty or blocked');
      return html;
    }).catch(function () {
      return request(url, { Referer: BASE + '/' }).then(function (r) {
        if (!acceptablePage(r.text)) throw new Error('Cloudflare challenge while opening ' + url);
        return r.text;
      });
    });
  }
  function fromInput(value) {
    var s = String(value || '').trim();
    if (!s) throw new Error('Missing title URL or ID');
    if (/^https?:\/\//i.test(s)) return s;
    if (s.charAt(0) === '/') return BASE + s;
    return BASE + '/' + s.replace(/^\/+|\/+$/g, '') + '/';
  }
  function slugOf(u) {
    var m = String(u || '').match(/\/([^/?#]+)\/?(?:\?[^#]*)?$/);
    return m ? m[1] : String(u || '').replace(/[/?#]/g, '-');
  }
  function isContentUrl(u) {
    if (!/^https?:\/\//.test(u)) return false;
    var base = origin(u).replace(/^https?:\/\/(?:www\.)?/, '');
    if (base !== 'hdfilmcehennemi.nl') return false;
    var path = u.slice(origin(u).length).replace(/[?#][\s\S]*$/, '');
    return /^\/(?!category\/|yil\/|tur\/|genre\/|search\/|tag\/|diller\/|dil\/|page\/|filmler\/|series\/|actor\/|oyuncu\/|author\/|wp-|admin|login|register|hakkimizda|iletisim|fragman|film-arsivi|dizi-arsivi)(?:dizi\/)?[^/]+(?:\/[\s\S]*)?\/?$/i.test(path);
  }
  function buildItem(url, title, img) {
    var href = abs(url);
    if (!isContentUrl(href)) return null;
    title = clean(title || '').replace(/\s*\|\s*HDFilmCehennemi.*$/i, '').trim();
    if (!title) title = slugOf(href).replace(/-/g, ' ');
    var image = abs(img || '', href);
    return { title: title, href: href, image: image, id: slugOf(href) };
  }
  function parseSnippets(snippets, limit) {
    var out = [], seen = {};
    for (var i = 0; i < snippets.length; i++) {
      var html = String(snippets[i] || '');
      var a = html.match(/<a\b[^>]*href\s*=\s*(["'])(.*?)\1[^>]*>/i);
      if (!a) continue;
      var titleMatch = html.match(/<h[2-5]\b[^>]*class\s*=\s*["'][^"']*title[^"']*["'][^>]*>([\s\S]*?)<\/h[2-5]>/i);
      var imageMatch = html.match(/<img\b[^>]*>/i);
      var yearMatch = html.match(/<span\b[^>]*class\s*=\s*["'][^"']*year[^"']*["'][^>]*>([\s\S]*?)<\/span>/i);
      var item = buildItem(a[2], titleMatch ? titleMatch[1] : attr(a[0], 'title') || (imageMatch ? attr(imageMatch[0], 'alt') : ''), imageMatch ? (attr(imageMatch[0], 'data-src') || attr(imageMatch[0], 'src')) : '');
      if (!item || seen[item.href]) continue;
      if (yearMatch && !/\b(?:19|20)\d{2}\b/.test(clean(yearMatch[1]))) continue;
      seen[item.href] = true; out.push(item);
      if (out.length >= limit) break;
    }
    return out;
  }
  function parseCards(html, limit) {
    var out = [], seen = {}, re = /<a\b[^>]*href\s*=\s*(["'])([^"']+)\1[^>]*>/gi, m;
    while ((m = re.exec(html)) && out.length < limit) {
      var tag = m[0], url = abs(m[2]);
      if (!isContentUrl(url) || seen[url]) continue;
      var rest = html.slice(re.lastIndex, Math.min(html.length, re.lastIndex + 2000));
      var closeAt = rest.indexOf('</a>');
      if (closeAt >= 0) rest = rest.slice(0, closeAt);
      var nearby = html.slice(Math.max(0, m.index - 180), Math.min(html.length, re.lastIndex + 2100));
      var img = (rest.match(/<img\b[^>]*>/i) || nearby.match(/<img\b[^>]*>/i) || [])[0] || '';
      var titleTag = rest.match(/<(?:h2|h3|h4|h5)\b[^>]*>([\s\S]*?)<\/(?:h2|h3|h4|h5)>/i);
      var title = titleTag ? clean(titleTag[1]) : attr(tag, 'title') || attr(img, 'alt');
      if (!title && !img) continue;
      var item = buildItem(url, title, attr(img, 'data-src') || attr(img, 'src'));
      if (!item) continue;
      seen[url] = true; out.push(item);
    }
    return out;
  }
  function searchResults(query) {
    var q = String(query || '').trim();
    if (!q) {
      return request(BASE + '/', { 'Referer': BASE + '/' }).then(function (r) {
        if (!acceptablePage(r.text)) throw new Error('HDFilmCehennemi home blocked by Cloudflare');
        var found = parseCards(r.text, 60);
        if (found.length) return found;
        return fetchPage(BASE + '/category/film-izle-2/').then(function (html) { return parseCards(html, 60); });
      });
    }
    var u = BASE + '/search/?q=' + encodeURIComponent(q);
    return request(u, {
      'Accept': 'application/json, */*',
      'X-Requested-With': 'fetch',
      'Referer': BASE + '/'
    }).then(function (r) {
      var data = parseJson(r.text);
      if (data && Array.isArray(data.results)) return parseSnippets(data.results, 60);
      if (acceptablePage(r.text)) return parseCards(r.text, 60);
      throw new Error('Search challenge page received');
    });
  }
  function getMeta(html, key, kind) {
    var tags = html.match(/<meta\b[^>]*>/gi) || [];
    for (var i = 0; i < tags.length; i++) {
      if (attr(tags[i], kind || 'property').toLowerCase() === String(key).toLowerCase()) return attr(tags[i], 'content');
    }
    return '';
  }
  function parseDetail(html, href) {
    var heading = html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i);
    var title = heading ? clean(heading[1]) : getMeta(html, 'og:title') || getMeta(html, 'twitter:title');
    if (!title) { var t = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i); title = t ? clean(t[1]) : ''; }
    title = title.replace(/\s*(?:izle|film izle|dizi izle)\s*(?:\||[-–]).*$/i, '').trim();
    var desc = getMeta(html, 'og:description') || getMeta(html, 'description', 'name');
    var bodyDesc = html.match(/<(?:div|p)\b[^>]*class\s*=\s*["'][^"']*(?:description|summary|overview|film-aciklama|content-text)[^"']*["'][^>]*>([\s\S]*?)<\/(?:div|p)>/i);
    if (bodyDesc && clean(bodyDesc[1]).length > desc.length) desc = clean(bodyDesc[1]);
    var image = getMeta(html, 'og:image') || getMeta(html, 'twitter:image', 'name');
    if (!image) {
      var poster = html.match(/<img\b[^>]*(?:poster|film-image|cover)[^>]*>/i);
      image = poster && (attr(poster[0], 'data-src') || attr(poster[0], 'src')) || '';
    }
    return { title: title || slugOf(href).replace(/-/g, ' '), description: clean(desc), image: abs(image, href), href: href, id: slugOf(href) };
  }
  function extractDetails(urlOrId) {
    var href = fromInput(urlOrId);
    return fetchPage(href).then(function (h) { return parseDetail(h, href); });
  }
  function episodeMatches(html, base) {
    var out = [], seen = {}, re = /<a\b[^>]*href\s*=\s*(["'])([^"']+)\1[^>]*>/gi, m;
    while ((m = re.exec(html))) {
      var href = abs(m[2], base), s = 0, e = 0;
      var path = href.slice(origin(href).length);
      var p = path.match(/sezon[-\/]?(\d+)[\/\-_]*bolum[-\/]?(\d+)/i) || path.match(/(\d+)-sezon-(\d+)-bolum/i);
      if (!p) continue;
      s = Number(p[1]); e = Number(p[2]);
      if (!s || !e || s > 99 || e > 999) continue;
      var key = s + ':' + e;
      if (seen[key]) continue;
      seen[key] = true;
      out.push({ season: s, episode: e, href: href });
    }
    out.sort(function (a, b) { return a.season - b.season || a.episode - b.episode; });
    return out;
  }
  function extractEpisodes(seriesId) {
    var href = fromInput(seriesId);
    return fetchPage(href).then(function (html) {
      var items = episodeMatches(html, href);
      if (!items.length) {
        var seasonEpisode = href.match(/sezon[-\/](\d+).*?bolum[-\/](\d+)/i);
        var number = seasonEpisode ? +seasonEpisode[2] : 1;
        return [{ number: number, href: href, subAvailable: true, dubAvailable: true }];
      }
      return items.map(function (ep, i) {
        return { number: i + 1, href: ep.href, season: ep.season, episode: ep.episode, subAvailable: true, dubAvailable: true };
      });
    });
  }
  function sourceOptions(html) {
    var result = [], seen = {}, m;
    var sections = /<div\b[^>]*class\s*=\s*(["'])[^"']*alternative-links[^"']*\1[^>]*data-lang\s*=\s*(["'])(.*?)\2[^>]*>([\s\S]*?)<\/div>/gi;
    while ((m = sections.exec(html))) {
      var lang = m[3], section = m[4], br = /<button\b[^>]*data-video\s*=\s*(["'])([^"']+)\1[^>]*>([\s\S]*?)<\/button>/gi, bm;
      while ((bm = br.exec(section))) {
        var name = clean(bm[3]) || 'Close';
        if (!seen[bm[2]]) { seen[bm[2]] = true; result.push({ id: bm[2], label: name, lang: lang }); }
      }
    }
    if (!result.length) {
      var br2 = /<button\b[^>]*data-video\s*=\s*(["'])([^"']+)\1[^>]*>([\s\S]*?)<\/button>/gi;
      while ((m = br2.exec(html))) {
        if (seen[m[2]]) continue;
        seen[m[2]] = true; result.push({ id: m[2], label: clean(m[3]) || 'Close', lang: '' });
      }
    }
    return result;
  }
  function orderSources(items, requested) {
    var q = String(requested || 'sub').toLowerCase();
    var dub = /dub|tur|dublaj|tr\b/.test(q);
    return items.slice().sort(function (a, b) {
      function score(x) {
        var text = (x.label + ' ' + x.lang).toLowerCase();
        var s = /rapidrame/.test(text) ? 10 : 0;
        if (dub) s += /dub|dublaj|turkce|türkçe|tr\b/.test(text) ? 0 : 5;
        else s += /altyazi|altyazı|sub|orijinal|orj|en\b/.test(text) ? 0 : 5;
        return s;
      }
      return score(a) - score(b);
    });
  }
  function quotedParts(str) {
    var result = [], m, re = /(["'])([^"']+)\1/g;
    while ((m = re.exec(str))) result.push(m[2]);
    return result;
  }
  function base64Latin1(value) {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var s = String(value || '').replace(/[^a-z0-9+/=]/gi, ''), out = '', acc = 0, bits = 0;
    for (var i = 0; i < s.length; i++) {
      if (s.charAt(i) === '=') break;
      var v = chars.indexOf(s.charAt(i)); if (v < 0) continue;
      acc = (acc << 6) | v; bits += 6;
      if (bits >= 8) { bits -= 8; out += String.fromCharCode((acc >>> bits) & 255); }
    }
    return out;
  }
  function rotLetters(str, n) {
    return String(str).replace(/[a-z]/gi, function (ch) {
      var cp = ch.charCodeAt(0), base = cp <= 90 ? 65 : 97;
      return String.fromCharCode(base + ((cp - base + n) % 26));
    });
  }
  function decodeSteps(parts, steps) {
    var data = parts.join('');
    for (var i = 0; i < steps.length; i++) {
      var step = steps[i], j, tmp;
      if (step.type === 'b64') data = base64Latin1(data);
      else if (step.type === 'reverse') data = data.split('').reverse().join('');
      else if (step.type === 'rot') data = rotLetters(data, step.shift);
      else if (step.type === 'unmix') {
        tmp = '';
        for (j = 0; j < data.length; j++) tmp += String.fromCharCode((data.charCodeAt(j) - (step.magic % (j + step.offset)) + 512) % 256);
        data = tmp;
      } else if (step.type === 'xor') {
        tmp = ''; var acc = step.seed;
        for (j = 0; j < data.length; j++) {
          var code = data.charCodeAt(j); acc = (acc + step.increment) % 256;
          tmp += String.fromCharCode(code ^ acc); acc = (acc + code) % 256;
        }
        data = tmp;
      }
    }
    return data;
  }
  function inlineDecoders(html) {
    var out = [], f = /function\s+(dc_\w+)\s*\(\s*[\w$]+\s*\)\s*\{([\s\S]*?)\n\}/gi, m;
    while ((m = f.exec(html))) {
      var name = m[1], body = m[2];
      var call = html.match(new RegExp(name + '\\s*\\(\\s*\\[([^\\]]+)\\]\\s*\\)', 'i'));
      if (!call) continue;
      var parts = quotedParts(call[1]); if (!parts.length) continue;
      var steps = [], re = /=\s*atob\(\s*result\s*\)|result\.split\(['"]['"]\)\.reverse\(\)\.join\(['"]['"]\)|\(o\s*-\s*base\s*\+\s*(\d+)\)\s*%\s*26|charCode\s*-\s*\((\d+)\s*%\s*\(i\s*\+\s*(\d+)\)\)|var\s+acc\s*=\s*(\d+)[\s\S]{0,240}?acc\s*=\s*\(\s*acc\s*\+\s*(\d+)\s*\)\s*%\s*256/gi, match;
      while ((match = re.exec(body))) {
        if (/atob/.test(match[0])) steps.push({ type: 'b64' });
        else if (/\.reverse\(/.test(match[0])) steps.push({ type: 'reverse' });
        else if (match[1] !== undefined) steps.push({ type: 'rot', shift: +match[1] });
        else if (match[2] !== undefined) steps.push({ type: 'unmix', magic: +match[2], offset: +match[3] });
        else steps.push({ type: 'xor', seed: +match[4], increment: +match[5] });
      }
      if (steps.length) out.push({ parts: parts, steps: steps });
    }
    return out;
  }
  function streamCandidate(u) {
    return /^https?:\/\//i.test(u) && /(?:\.m3u8|\.mp4|\/hls\/|\/master\.txt)(?:[?#]|$)/i.test(u);
  }
  function plainMedia(html) {
    var list = [], re = /(?:file|source|src|contentUrl)\s*[:=]\s*(["'])(https?:\/\/[^"'\s]+)\1/gi, m;
    while ((m = re.exec(html))) if (streamCandidate(m[2])) list.push(unescapeJs(m[2]));
    var re2 = /(["'])(https?:\/\/[^"'\s]+(?:\.m3u8|\.mp4|\/master\.txt)(?:\?[^"'\s]*)?)\1/gi;
    while ((m = re2.exec(html))) list.push(unescapeJs(m[2]));
    return list;
  }
  function findEmbeds(html, base) {
    var found = [], seen = {}, re = /<iframe\b[^>]*>/gi, m;
    while ((m = re.exec(html))) {
      var src = abs(attr(m[0], 'data-src') || attr(m[0], 'src'), base);
      if (src && !seen[src]) { seen[src] = true; found.push(src); }
    }
    return found;
  }
  function decodeEmbedded(html) {
    var result = [], ds = inlineDecoders(html);
    for (var i = 0; i < ds.length; i++) {
      try {
        var u = decodeSteps(ds[i].parts, ds[i].steps);
        if (streamCandidate(u)) result.push(u);
      } catch (_) {}
    }
    return result.concat(plainMedia(html));
  }
  function resolveEmbed(iframe, referer) {
    var src = abs(iframe, referer);
    if (!src) return Promise.resolve([]);
    var sourceOrigin = origin(src), headers = { 'Referer': referer, 'Origin': origin(referer) };
    return request(src, headers).then(function (r) {
      if (!acceptablePage(r.text)) throw new Error('Embed provider challenge: ' + sourceOrigin);
      var urls = decodeEmbedded(r.text).map(function (url) {
        return { label: 'Auto', url: url, headers: { 'User-Agent': UA, 'Referer': sourceOrigin + '/', 'Origin': sourceOrigin, 'Accept': '*/*' } };
      });
      if (urls.length) return urls;
      var nested = findEmbeds(r.text, src);
      if (nested.length) return resolveEmbed(nested[0], src);
      return [];
    });
  }
  function apiVideo(videoId, pageUrl) {
    var url = BASE + '/video/' + encodeURIComponent(videoId) + '/';
    return request(url, { 'X-Requested-With': 'fetch', 'Accept': 'application/json, */*', 'Referer': pageUrl }).then(function (r) {
      var inner = htmlFromData(r.text), iframe = findEmbeds(inner, url)[0];
      if (!iframe) {
        var m = inner.match(/(?:data-src|src)\s*=\s*\\?"([^"\s]+)\\?"/i);
        if (m) iframe = abs(m[1], url);
      }
      if (!iframe) throw new Error('Video provider returned no iframe for video ID ' + videoId);
      return resolveEmbed(iframe, pageUrl);
    });
  }
  function headerValue(headers, name) {
    if (!headers) return '';
    if (typeof headers.get === 'function') { try { return String(headers.get(name) || ''); } catch (_) {} }
    var keys = Object.keys(headers);
    for (var i = 0; i < keys.length; i++) if (keys[i].toLowerCase() === name.toLowerCase()) return String(headers[keys[i]]);
    return '';
  }
  function probe(candidate) {
    var isMp4 = /\.mp4(?:[?#]|$)/i.test(candidate.url), h = mix(candidate.headers, { 'Accept': 'application/x-mpegURL,application/vnd.apple.mpegurl,video/*,*/*;q=0.8' });
    if (isMp4) h['Range'] = 'bytes=0-8191';
    return request(candidate.url, h).then(function (r) {
      var t = r.text.trim(), ct = headerValue(r.headers, 'content-type').toLowerCase();
      if (/^(?:<!doctype\s+html|<html\b|<head\b|<body\b)/i.test(t) || /text\/html/i.test(ct)) return false;
      if (t.indexOf('#EXTM3U') === 0 || /(?:mpegurl|application\/vnd\.apple)/.test(ct)) return true;
      return isMp4 && (ct.indexOf('video/') === 0 || t.indexOf('ftyp') >= 0);
    }, function (_) { return false; });
  }
  function chooseVerified(candidates) {
    var errors = [], seen = {};
    function next(i) {
      if (i >= candidates.length) throw new Error('No direct playable MP4/HLS stream verified (' + errors.join(' | ') + ')');
      var c = candidates[i];
      if (!c.url || seen[c.url]) return next(i + 1);
      seen[c.url] = true;
      return probe(c).then(function (ok) {
        if (!ok) { errors.push('Not media: ' + c.label); return next(i + 1); }
        return { streams: [c.label || 'Auto', c.url], headers: c.headers || {}, streamType: /\.mp4(?:[?#]|$)/i.test(c.url) ? 'mp4' : 'hls' };
      });
    }
    return next(0);
  }
  function extractStreamUrl(episodeHref, lang) {
    var href = fromInput(episodeHref);
    return fetchPage(href).then(function (html) {
      var sourceList = orderSources(sourceOptions(html), lang);
      var direct = findEmbeds(html, href);
      var candidates = [];
      function processSource(i) {
        if (i >= sourceList.length) {
          if (direct.length) {
            return resolveEmbed(direct[0], href).then(function (arr) {
              candidates = candidates.concat(arr);
              return chooseVerified(candidates);
            });
          }
          return chooseVerified(candidates);
        }
        var x = sourceList[i];
        return apiVideo(x.id, href).then(function (arr) {
          var label = (x.lang ? x.lang + ' | ' : '') + (x.label || 'Auto');
          for (var k = 0; k < arr.length; k++) { arr[k].label = label; candidates.push(arr[k]); }
          return chooseVerified(candidates);
        }).catch(function () {
          return processSource(i + 1);
        });
      }
      return processSource(0);
    });
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
})();
