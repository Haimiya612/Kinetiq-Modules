/** ReAnime Library for Synthetiq Player V3 - local ES2019 runtime.
 * No imports, eval, dynamic code, external scripts or bundled media.
 * The FlixCloud source adapter only uses source-page crypto data and local JS.
 */
(function () {
  'use strict';
  var BASE = 'https://reanime.to';
  var FLIX = 'https://flixcloud.cc';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
  var HEADERS = { 'User-Agent': UA, 'Accept': 'text/html,application/json,application/vnd.apple.mpegurl,*/*;q=0.8', 'Referer': BASE + '/' };
  function merge(a,b) { var r={},k; for(k in a) if(Object.prototype.hasOwnProperty.call(a,k)) r[k]=a[k]; for(k in b) if(Object.prototype.hasOwnProperty.call(b,k)) r[k]=b[k]; return r; }
  function abs(u,base) { u=String(u||'').trim(); base=base||BASE+'/'; if(!u)return '';if(/^https?:\/\//i.test(u))return u;if(u.indexOf('//')===0)return 'https:'+u;var a=base.match(/^(https?:\/\/[^\/]+)(\/[^?#]*)?/);if(!a)return u; if(u.charAt(0)==='/')return a[1]+u;var path=(a[2]||'/').replace(/\/[^/]*$/,'/');while(u.indexOf('../')===0){u=u.slice(3);path=path.replace(/[^/]+\/$/,'');}return a[1]+path+u.replace(/^\.\//,''); }
  function de(s) {return String(s||'').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#(?:39|x27);/gi,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&nbsp;/g,' ').replace(/&#(\d+);/g,function(_,v){return String.fromCharCode(+v);}).replace(/&#x([\da-f]+);/gi,function(_,v){return String.fromCharCode(parseInt(v,16));});}
  function clean(s) {return de(String(s||'').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ')).trim();}
  function attr(t,k) {var m=String(t||'').match(new RegExp('\\b'+k+'\\s*=\\s*(["\\\'])([\\s\\S]*?)\\1','i'));return m?de(m[2]):'';}
  // fetchv2 and fetch expose the same bytes through slightly different shapes.
  // Prefer the native response body; do not treat an empty .text() as content
  // when a nonempty .json() result is still available.
  function ptext(r) {
    if (r === null || r === undefined) return Promise.resolve('');
    if (typeof r === 'string') return Promise.resolve(r);
    if (typeof r.body === 'string' && r.body.length) return Promise.resolve(r.body);
    if (r.body != null && typeof r.body === 'object' && typeof r.body.then !== 'function') {
      try { return Promise.resolve(JSON.stringify(r.body)); } catch (_) {}
    }
    function jsonFallback() {
      if (typeof r.json !== 'function') return Promise.resolve('');
      try { return Promise.resolve(r.json()).then(function (x) {
        return x == null ? '' : (typeof x === 'string' ? x : JSON.stringify(x));
      }).catch(function () { return ''; }); } catch (_) { return Promise.resolve(''); }
    }
    if (typeof r.text === 'function') {
      try { return Promise.resolve(r.text()).then(function (x) {
        var value = typeof x === 'string' ? x : (x == null ? '' : JSON.stringify(x));
        return value.length ? value : jsonFallback();
      }).catch(function () { return jsonFallback(); }); } catch (_) {}
    }
    return jsonFallback();
  }
  function http(url, extra,method,body){var headers=merge(HEADERS,extra||{});method=method||'GET';var f;
    if(typeof fetchv2==='function') f=fetchv2(url,headers,method,body==null?null:body);
    else if(typeof fetch==='function'){var o={method:method,headers:headers};if(body!=null&&method!=='GET')o.body=body;f=fetch(url,o);}
    else throw new Error('No fetchv2/fetch available for ReAnime');
    return Promise.resolve(f).then(function(r){return ptext(r).then(function(s){var status=Number((r&&(r.status||r.statusCode))||200);if(status<200||status>=400)throw new Error('Source request returned HTTP '+status);return {text:String(s||''),headers:(r&&r.headers)||{},status:status,url:(r&&r.url)||url};});});
  }
  function json(url,headers){return http(url,headers).then(function(r){try{return JSON.parse(r.text);}catch(_){throw new Error('Source request returned a non-JSON response');}});}
  function slug(x){x=String(x||'');var m=x.match(/\/(?:anime|watch)\/([^?#/]+)/i);return m?de(m[1]):x.replace(/^\/+|\/+$/g,'').replace(/\?.*$/,'');}
  function animeUrl(id){return BASE+'/anime/'+encodeURIComponent(slug(id));}
  function watchUrl(id,ep){return BASE+'/watch/'+encodeURIComponent(slug(id))+'?ep='+encodeURIComponent(ep||1);}
  function parseCards(html,max){var cards=[],seen={},re=/<a\b[^>]*href\s*=\s*(["'])([^"']*\/anime\/[^"'?#/]+)\1[^>]*>([\s\S]*?)<\/a>/gi,m;
    while((m=re.exec(html))){var href=abs(de(m[2]));if(href.indexOf(BASE+'/anime/')!==0)continue;var id=slug(href);if(seen[id])continue;var tag=m[3];var images=tag.match(/<img\b[^>]*>/gi)||[];var image='',title='';for(var i=0;i<images.length;i++){var a=attr(images[i],'alt'),src=attr(images[i],'src')||attr(images[i],'data-src');if(a&&!/re:anime|avatar|profile|placeholder/i.test(a))title=a;if(src&&!image)image=abs(src,href);}var t=tag.match(/<h[1-6][^>]*>([\s\S]*?)<\/h[1-6]>/i);if(t&&clean(t[1]))title=clean(t[1]);if(!title){var tt=tag.match(/\btitle\s*=\s*(["'])(.*?)\1/i);if(tt)title=de(tt[2]);}if(!title)title=id.replace(/-[a-z0-9]{6}$/,'').replace(/-/g,' ');seen[id]=1;cards.push({title:title,href:href,image:image,id:id});if(cards.length>=max)break;}return cards;
  }
  function searchResults(query){query=String(query||'').trim();var path=query?'/search?q='+encodeURIComponent(query):'/home';return http(BASE+path).then(function(r){var c=parseCards(r.text,60);if(!c.length)throw new Error('ReAnime listing contained no anime cards. Site markup may have changed.');return c;});}
  function propertyString(s,name){var re=new RegExp('(?:^|[,\\{])\\s*(?:"'+name+'"|'+name+')\\s*:\\s*"((?:\\\\.|[^"\\\\])*)"','i');var m=String(s||'').match(re);if(!m)return '';try{return JSON.parse('"'+m[1]+'"');}catch(_){return m[1].replace(/\\u003c/gi,'<').replace(/\\n/g,'\n').replace(/\\\"/g,'"').replace(/\\\//g,'/');}}
  function propNum(s,key){var m=String(s||'').match(new RegExp('(?:^|[,\\{])\\s*'+key+'\\s*:\\s*(\\d+)','i'));return m?+m[1]:0;}
  function headMeta(html,key){var re=/<meta\b[^>]*>/gi,m;while((m=re.exec(html))){if(attr(m[0],'property')===key || attr(m[0],'name')===key)return attr(m[0],'content');}return '';}
  function detailsFromHtml(html,id){var title='',image='',desc='';var serialized=html.slice(html.lastIndexOf('node_ids:'));
    var m=serialized.match(/\banime:\{[\s\S]{0,6000}?\btitle:\{([^}]+)\}/);
    if(m)title=propertyString('{'+m[1]+'}','english')||propertyString('{'+m[1]+'}','user_preferred')||propertyString('{'+m[1]+'}','romaji');
    var t=html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i);if(!title&&t)title=clean(t[1]);if(!title)title=headMeta(html,'og:title').replace(/\s*[-|].*$/,'');
    image=headMeta(html,'og:image');
    if(!image){var p=serialized.match(/\bcover_image:\{[\s\S]{0,500}?\}/);if(p)image=propertyString(p[0],'extra_large')||propertyString(p[0],'extraLarge')||propertyString(p[0],'large');}
    var d=serialized.match(/\banime:\{[\s\S]{0,12000}?\bdescription:"((?:\\.|[^"\\])*)"/);if(d){try{desc=clean(JSON.parse('"'+d[1]+'"'));}catch(_){desc=clean(d[1]);}}
    if(!desc)desc=headMeta(html,'og:description')||headMeta(html,'description');
    title=title||slug(id).replace(/-[a-z0-9]{6}$/,'').replace(/-/g,' ');
    return {title:title,description:desc,image:abs(image),id:slug(id),href:animeUrl(id)};
  }
  function extractDetails(id){return http(animeUrl(id)).then(function(r){return detailsFromHtml(r.text,id);});}
  function extractEpisodes(seriesId){var id=slug(seriesId);return http(watchUrl(id,1)).then(function(r){
    var html=r.text,out=[],seen={};
    // Full episode catalogue is serialized on the server (unlike the UI, which shows 30 at a time).
    var s=html.lastIndexOf('node_ids:');if(s>=0){var a=html.slice(s).match(/\bepisodes:\[([\s\S]*?)\],currentEpisode:/);if(a){var e=/\{[^{}]*?\bepisode_number:(\d+)[^{}]*?\}/g,m;while((m=e.exec(a[1]))){var obj=m[0],n=+m[1];if(!n||seen[n]||!/\bplayable:true\b/.test(obj))continue;seen[n]=1;out.push({number:n,href:watchUrl(id,n),subAvailable:/\bsubbed:true\b/.test(obj),dubAvailable:/\bdubbed:true\b/.test(obj)});}}}
    if(!out.length){var re=/<a\b[^>]*href\s*=\s*(["'])([^"']*\/watch\/[^"']+\bep=(\d+)[^"']*)\1[^>]*>/gi,m;while((m=re.exec(html))){var n=+m[3];if(!n||seen[n])continue;seen[n]=1;var tag=m[0],info=attr(tag,'title').toLowerCase();out.push({number:n,href:abs(de(m[2])),subAvailable:info.indexOf('sub')>=0||!info,dubAvailable:info.indexOf('dub')>=0});}}
    if(!out.length)throw new Error('ReAnime episode list missing for '+id);
    out.sort(function(a,b){return a.number-b.number;});return out;
  });}
  // No WebCrypto, Buffer, Node modules, WebAssembly, eval, or dynamic JS required.
  function utf8(s){var out=[],i,c;for(i=0;i<s.length;i++){c=s.charCodeAt(i);if(c<128)out.push(c);else if(c<2048)out.push(192|(c>>6),128|(c&63));else if(c>=0xD800&&c<=0xDBFF&&i+1<s.length){var d=s.charCodeAt(++i),cp=0x10000+((c-0xD800)<<10)+(d-0xDC00);out.push(240|(cp>>18),128|((cp>>12)&63),128|((cp>>6)&63),128|(cp&63));}else out.push(224|(c>>12),128|((c>>6)&63),128|(c&63));}return out;}
  function fromUtf8(b){var s='',i=0,c;while(i<b.length){c=b[i++];if(c<128)s+=String.fromCharCode(c);else if((c&224)===192&&i<b.length)s+=String.fromCharCode(((c&31)<<6)|(b[i++]&63));else if((c&240)===224&&i+1<b.length)s+=String.fromCharCode(((c&15)<<12)|((b[i++]&63)<<6)|(b[i++]&63));else if((c&248)===240&&i+2<b.length){var cp=((c&7)<<18)|((b[i++]&63)<<12)|((b[i++]&63)<<6)|(b[i++]&63);cp-=0x10000;s+=String.fromCharCode(0xD800+(cp>>10),0xDC00+(cp&1023));}else s+='?';}return s;}
  function b64(s){s=String(s||'').replace(/[^\da-zA-Z+/=]/g,'');var a='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out=[],t=0,b=0;for(var i=0;i<s.length;i++){if(s[i]==='=')break;var v=a.indexOf(s[i]);if(v<0)continue;t=(t<<6)|v;b+=6;if(b>=8){b-=8;out.push((t>>b)&255);}}return out;}
  function hex(b){var s='';for(var i=0;i<b.length;i++)s+=('0'+b[i].toString(16)).slice(-2);return s;}
  var K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  function rotr(x,n){return(x>>>n)|(x<<(32-n));}
  function sha256(input){var data=Array.isArray(input)?input.slice():utf8(String(input));var bitHi=Math.floor(data.length/0x20000000),bitLo=(data.length*8)>>>0;data.push(128);while(data.length%64!==56)data.push(0);data.push((bitHi>>>24)&255,(bitHi>>>16)&255,(bitHi>>>8)&255,bitHi&255,(bitLo>>>24)&255,(bitLo>>>16)&255,(bitLo>>>8)&255,bitLo&255);
    var H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19],w=new Array(64);
    for(var pos=0;pos<data.length;pos+=64){var i;for(i=0;i<16;i++){var j=pos+i*4;w[i]=((data[j]<<24)|(data[j+1]<<16)|(data[j+2]<<8)|data[j+3])>>>0;}for(i=16;i<64;i++){var x=w[i-15],y=w[i-2];w[i]=(w[i-16]+(rotr(x,7)^rotr(x,18)^(x>>>3))+w[i-7]+(rotr(y,17)^rotr(y,19)^(y>>>10)))>>>0;}
      var a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];for(i=0;i<64;i++){var t1=(h+(rotr(e,6)^rotr(e,11)^rotr(e,25))+((e&f)^(~e&g))+K[i]+w[i])>>>0,t2=((rotr(a,2)^rotr(a,13)^rotr(a,22))+((a&b)^(a&c)^(b&c)))>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}H[0]=(H[0]+a)>>>0;H[1]=(H[1]+b)>>>0;H[2]=(H[2]+c)>>>0;H[3]=(H[3]+d)>>>0;H[4]=(H[4]+e)>>>0;H[5]=(H[5]+f)>>>0;H[6]=(H[6]+g)>>>0;H[7]=(H[7]+h)>>>0;
    }var out=[];for(var n=0;n<8;n++)out.push((H[n]>>>24)&255,(H[n]>>>16)&255,(H[n]>>>8)&255,H[n]&255);return out;
  }
  function shahex(x){return hex(sha256(x));}
  function hmac(key,msg){var k=key.slice();if(k.length>64)k=sha256(k);while(k.length<64)k.push(0);var inner=[],outer=[];for(var i=0;i<64;i++){inner.push(k[i]^0x36);outer.push(k[i]^0x5c);}return sha256(outer.concat(sha256(inner.concat(msg))));}
  function gfmul(a,b){var p=0;for(var i=0;i<8;i++){if(b&1)p^=a;var hi=a&128;a=(a<<1)&255;if(hi)a^=27;b>>=1;}return p;}
  function sboxes(){var box=[],inv=[];for(var i=0;i<256;i++){var x=i?1:0;if(i){for(var n=0;n<254;n++)x=gfmul(x,i);}var y=x^((x<<1)|(x>>>7))^((x<<2)|(x>>>6))^((x<<3)|(x>>>5))^((x<<4)|(x>>>4))^0x63;y&=255;box[i]=y;inv[y]=i;}return{box:box,inv:inv};}
  var SB=sboxes();
  function expandKey(key){if(key.length!==32)throw new Error('AES-256 requires 32-byte key');var w=key.slice(),rc=1;for(var n=8;n<60;n++){var t=w.slice((n-1)*4,n*4);if(n%8===0){t.push(t.shift());for(var i=0;i<4;i++)t[i]=SB.box[t[i]];t[0]^=rc;rc=gfmul(rc,2);}else if(n%8===4){for(var j=0;j<4;j++)t[j]=SB.box[t[j]];}for(var z=0;z<4;z++)w.push(w[(n-8)*4+z]^t[z]);}return w;}
  function decryptBlock(block,w){var s=block.slice(),i,j,r;
    function add(round){for(var n=0;n<16;n++)s[n]^=w[round*16+n];}
    function shift(){var t=s.slice();for(var row=1;row<4;row++)for(var col=0;col<4;col++)s[4*col+row]=t[4*((col-row+4)%4)+row];}
    function sub(){for(var n=0;n<16;n++)s[n]=SB.inv[s[n]];}
    function mix(){for(var col=0;col<4;col++){var j=col*4,a=s[j],b=s[j+1],c=s[j+2],d=s[j+3];s[j]=gfmul(a,14)^gfmul(b,11)^gfmul(c,13)^gfmul(d,9);s[j+1]=gfmul(a,9)^gfmul(b,14)^gfmul(c,11)^gfmul(d,13);s[j+2]=gfmul(a,13)^gfmul(b,9)^gfmul(c,14)^gfmul(d,11);s[j+3]=gfmul(a,11)^gfmul(b,13)^gfmul(c,9)^gfmul(d,14);}}
    add(14);for(r=13;r>=1;r--){shift();sub();add(r);mix();}shift();sub();add(0);return s;
  }
  function aesCbcDecrypt(cipher,key,iv){if(cipher.length%16!==0||!cipher.length||iv.length!==16)throw new Error('Invalid AES cipher/IV length');var w=expandKey(key),out=[],prev=iv;for(var p=0;p<cipher.length;p+=16){var chunk=cipher.slice(p,p+16),plain=decryptBlock(chunk,w);for(var i=0;i<16;i++)out.push(plain[i]^prev[i]);prev=chunk;}var pad=out[out.length-1];if(pad<1||pad>16)throw new Error('AES padding check failed');for(var j=out.length-pad;j<out.length;j++)if(out[j]!==pad)throw new Error('AES padding check failed');return fromUtf8(out.slice(0,out.length-pad));}
  function cryptNames(seed){var e=seed,l;for(var i=0;i<3;i++)e=shahex(e+i);l=e;for(i=0;i<3;i++)l=shahex(l+i);return{kf:'kf_'+e.slice(8,16),ivf:'ivf_'+e.slice(16,24),container:'cd_'+e.slice(24,32),array:'ad_'+e.slice(32,40),object:'od_'+e.slice(40,48),token:e.slice(48,64)+'_'+e.slice(56,64),kf2:l.slice(0,16)+'_'+l.slice(16,24)};}
  // SvelteKit embeds a nested `type:"data",data:{...}` structure. Dynamic
  // crypto fields can be far away from obfuscation_seed in the same structure.
  // Limit extraction to a balanced data object rather than looking just 50 KB
  // before the last seed occurrence (which can select the wrong object).
  // Never eval page JavaScript or load provider WASM into the JS runtime.
  function flixDataRegions(html) {
    var regions = [], start = /\{\s*type\s*:\s*["']data["']\s*,\s*data\s*:\s*\{/g, m;
    while ((m = start.exec(html)) && regions.length < 24) {
      var open = html.indexOf('{', m.index + m[0].length - 1);
      if (open < 0) continue;
      var depth = 0, quote = '', escaped = false, close = -1;
      for (var i = open; i < html.length && i < open + 1500000; i++) {
        var ch = html.charAt(i);
        if (quote) {
          if (escaped) escaped = false;
          else if (ch === '\\') escaped = true;
          else if (ch === quote) quote = '';
        } else if (ch === '"' || ch === "'" || ch === '`') {
          quote = ch;
        } else if (ch === '{') {
          depth++;
        } else if (ch === '}') {
          if (--depth === 0) { close = i; break; }
        }
      }
      if (close > open) {
        var region = html.slice(open, close + 1);
        if (region.indexOf('obfuscation_seed') >= 0) regions.push(region);
        start.lastIndex = close + 1;
      }
    }
    // Older FlixCloud embeds don't always use the SvelteKit data wrapper.
    // This last resort is bounded to one seed-bearing script, not guessed keys.
    if (!regions.length) {
      var k = html.lastIndexOf('obfuscation_seed');
      if (k >= 0) regions.push(html.slice(Math.max(0, k - 450000), Math.min(html.length, k + 450000)));
    }
    return regions;
  }
  function readEmbedPage(html) {
    var regions = flixDataRegions(String(html || ''));
    if (!regions.length) throw new Error('FlixCloud crypto envelope missing');
    var reasons = [];
    for (var i = 0; i < regions.length; i++) {
      var region = regions[i];
      var seed = propertyString(region, 'obfuscation_seed');
      if (!/^[a-f0-9]{12,64}$/i.test(seed)) { reasons.push('seed'); continue; }
      var names = cryptNames(seed);
      var f1 = propertyString(region, names.kf);
      var iv = propertyString(region, names.ivf);
      var f2 = propertyString(region, names.kf2);
      var token = propertyString(region, names.token);
      var wasm = propertyString(region, 'w_payload');
      if (!f1 || !iv || !f2 || !token) {
        // Report only which field class is missing, never rotating key names,
        // secret values, tokens or embed-page source.
        var missing = [];
        if (!f1) missing.push('key1');
        if (!iv) missing.push('iv');
        if (!f2) missing.push('key2');
        if (!token) missing.push('token');
        reasons.push(missing.join(','));
        continue;
      }
      if (!wasm) { reasons.push('transform'); continue; }
      var frag1 = b64(f1), ivBytes = b64(iv), frag2 = b64(f2);
      if (!frag1.length || ivBytes.length !== 16 || !frag2.length) {
        reasons.push('invalid crypto byte lengths'); continue;
      }
      return { seed: seed, frag1: frag1, iv: ivBytes,
        frag2: frag2, token: token, wasm: wasm };
    }
    throw new Error('FlixCloud crypto fields unavailable (' + reasons.slice(0,3).join('; ') + ')');
  }
  function pbkdfBytes(key,salt,iterations){var msg=utf8(salt).concat([0,0,0,1]),u=hmac(key,msg),v=u.slice();for(var i=1;i<iterations;i++){u=hmac(key,u);for(var j=0;j<v.length;j++)v[j]^=u[j];}return v;}
  // Override the password step to handle arbitrary WASM output bytes losslessly.
  // Executes only the tiny i32 byte-transform function supplied in FlixCloud's
  // page. It is a constrained interpreter, not a script engine or a WebAssembly
  // implementation; no external, remote or arbitrary JS code is evaluated.
  function lebU(buf,ref){var value=0,shift=0,byte;do{if(ref.pos>=buf.length)throw new Error('Truncated WASM LEB');byte=buf[ref.pos++];value|=(byte&127)<<shift;shift+=7;if(shift>35)throw new Error('WASM LEB too long');}while(byte&128);return value>>>0;}
  function lebS(buf,ref){var value=0,shift=0,byte;do{if(ref.pos>=buf.length)throw new Error('Truncated WASM signed LEB');byte=buf[ref.pos++];value|=(byte&127)<<shift;shift+=7;if(shift>35)throw new Error('WASM signed LEB too long');}while(byte&128);if(shift<32&&(byte&64))value|=(~0<<shift);return value|0;}
  function wasmRCode(payload){var bytes=b64(payload),p={pos:8};if(bytes.length<12||bytes[0]!==0||bytes[1]!==97||bytes[2]!==115||bytes[3]!==109)throw new Error('Invalid FlixCloud WASM');while(p.pos<bytes.length){var id=bytes[p.pos++],size=lebU(bytes,p),end=p.pos+size;if(end>bytes.length)throw new Error('WASM section overflow');if(id===10){var count=lebU(bytes,p);if(count<2)throw new Error('WASM _r function missing');for(var i=0;i<count;i++){var n=lebU(bytes,p),bodyEnd=p.pos+n;if(bodyEnd>end)throw new Error('WASM function exceeds code section');if(i!==1){p.pos=bodyEnd;continue;}var groups=lebU(bytes,p);for(var j=0;j<groups;j++){lebU(bytes,p);p.pos++;}return bytes.slice(p.pos,bodyEnd);}throw new Error('WASM _r code not found');}p.pos=end;}throw new Error('FlixCloud WASM code section absent');}
  function wasmByteTransform(payload,one,two,three,seed){var code=wasmRCode(payload),start=-1,p={pos:0},o;
    while(p.pos<code.length){o=code[p.pos++];if(o===13){lebU(code,p);start=p.pos;break;}
      if(o===2||o===3||o===4)p.pos++;else if(o===32||o===33||o===34||o===35||o===36||o===12||o===13||o===14||o===16||o===65)lebU(code,p);
      else if(o===40||o===45||o===46||o===58||o===59||o===44||o===43){lebU(code,p);lebU(code,p);}
      else if(o===11)break;
    }
    if(start<0)throw new Error('FlixCloud WASM loop guard missing');var len=one.length;if(len!==two.length||len!==three.length)throw new Error('FlixCloud key fragment lengths differ');var a=1024,b=a+len,c=b+len,d=c+len,mem=new Array(d+len+256).fill(0);for(var k=0;k<len;k++){mem[a+k]=one[k];mem[b+k]=two[k];mem[c+k]=three[k];}
    var globalSeed=seed|0;for(var idx=0;idx<len;idx++){var locals=[a,b,c,d,len,idx,0,0],stack=[],pc={pos:start},steps=0;
      function pop(){if(!stack.length)throw new Error('FlixCloud WASM stack underflow');return stack.pop()|0;}
      while(pc.pos<code.length){if(++steps>700)throw new Error('FlixCloud WASM transform too complex');o=code[pc.pos++];var v,x,y,align,offset;
        switch(o){
          case 11:case 12:pc.pos=code.length;break; // loop back/end: caller advances the index
          case 32:stack.push(locals[lebU(code,pc)]|0);break; // local.get
          case 33:locals[lebU(code,pc)]=pop();break; // local.set
          case 34:v=lebU(code,pc);x=pop();locals[v]=x;stack.push(x);break; // local.tee
          case 35:lebU(code,pc);stack.push(globalSeed);break; // global.get
          case 65:stack.push(lebS(code,pc));break; // i32.const
          case 69:x=pop();stack.push(x===0?1:0);break;
          case 70:y=pop();x=pop();stack.push(x===y?1:0);break;
          case 113:y=pop();x=pop();stack.push(x&y);break;
          case 114:y=pop();x=pop();stack.push(x|y);break;
          case 115:y=pop();x=pop();stack.push(x^y);break;
          case 116:y=pop();x=pop();stack.push(x<<(y&31));break;
          case 117:y=pop();x=pop();stack.push(x>>(y&31));break;
          case 118:y=pop();x=pop();stack.push(x>>>(y&31));break;
          case 119:y=pop();x=pop();stack.push((x<<(y&31))|(x>>>((32-(y&31))&31)));break;
          case 120:y=pop();x=pop();stack.push((x>>>(y&31))|(x<<((32-(y&31))&31)));break;
          case 106:y=pop();x=pop();stack.push((x+y)|0);break;
          case 107:y=pop();x=pop();stack.push((x-y)|0);break;
          case 108:y=pop();x=pop();stack.push(Math.imul(x,y));break;
          case 109:y=pop();x=pop();stack.push(y===0?0:(x/y)|0);break;
          case 110:y=pop();x=pop();stack.push(y===0?0:Math.floor((x>>>0)/(y>>>0))>>>0);break;
          case 112:y=pop();x=pop();stack.push(y===0?0:(x%y));break;
          case 71: y=pop();x=pop();stack.push(x!==y?1:0);break;
          case 79:y=pop();x=pop();stack.push((x>>>0)>=(y>>>0)?1:0);break;
          case 13:lebU(code,pc);if(pop())throw new Error('Unexpected inner WASM branch');break;
          case 2:case 3:case 4:pc.pos++;break;
          case 0x2d:align=lebU(code,pc);offset=lebU(code,pc);x=(pop()>>>0)+offset;stack.push(mem[x]||0);break;
          case 0x3a:align=lebU(code,pc);offset=lebU(code,pc);v=pop()&255;x=(pop()>>>0)+offset;if(x>=mem.length)throw new Error('FlixCloud WASM write out of bounds');mem[x]=v;break;
          default:throw new Error('Unsupported FlixCloud WASM opcode 0x'+o.toString(16));
        }
      }
    }
    return mem.slice(d,d+len);
  }

  function decryptFlix(data,payload){var vk=shahex(data.token+'vid').slice(0,10),kk=shahex(data.token+'key').slice(0,10),v=b64(payload[vk]),T=b64(payload[kk]);var f=data.frag1,g=data.frag2;if(!v.length||!T.length||f.length!==g.length||f.length!==T.length)throw new Error('FlixCloud encrypted fields incomplete');var seedInt=parseInt(data.seed.slice(0,8),16),out=wasmByteTransform(data.wasm,f,g,T,seedInt);var key=pbkdfBytes(out,data.seed,1000);for(var i=0;i<key.length;i++)key[i]^=data.seed.charCodeAt(i%data.seed.length);return aesCbcDecrypt(v,sha256(key),data.iv).trim();}
  function directMedia(html){html=de(String(html||'').replace(/\\\//g,'/').replace(/\\u0026/gi,'&'));var x=html.match(/https?:\/\/[^\s"'<>\\]+\.(?:m3u8|mp4)(?:\?[^\s"'<>\\]*)?/i);return x?x[0].replace(/[;,)}]+$/,''):'';}
  // A MIME label does not prove usable media. Check actual playlist bytes,
  // while identifying the failure without copying signed URLs or body content.
  function mediaProbe(url, headers) {
    return http(url, merge(headers, {
      'Accept': 'application/vnd.apple.mpegurl,application/x-mpegURL,video/*,*/*'
    })).then(function (r) {
      var body = String(r.text || '').replace(/^\uFEFF/, '').trim();
      var prefix = body.slice(0, 800);
      if (/<html|<!doctype|<body|captcha|cloudflare/i.test(prefix))
        throw new Error('Media endpoint returned HTML/challenge, not video');
      if (body.slice(0, 7) === '#EXTM3U') return true;
      var ct = '';
      if (r.headers && typeof r.headers.get === 'function') ct = r.headers.get('content-type') || '';
      else ct = (r.headers && (r.headers['content-type'] || r.headers['Content-Type'])) || '';
      if (/video\/mp4/i.test(ct) && /\.mp4(?:[?#]|$)/i.test(url) && body.length > 32) return true;
      if (/mpegurl|x-mpegurl/i.test(ct)) {
        if (!body.length) throw new Error('HLS MIME received but playlist body was empty');
        throw new Error('HLS MIME received but playlist header #EXTM3U is missing (' + body.length + ' chars)');
      }
      throw new Error('Media response did not contain a verified HLS playlist or MP4');
    });
  }
  function parseWatchHref(input){var id=slug(input),s=String(input||''),m=s.match(/[?&]ep=(\d+)/);return{id:id,ep:m?+m[1]:1};}
  function fromWebPageId(id,ep){return http(watchUrl(id,ep)).then(function(r){var data=r.text,aid=propNum(data.slice(data.lastIndexOf('node_ids:')),'anilist_id');if(!aid){var a=data.match(/anilist\.co\/anime\/(\d+)/);if(a)aid=+a[1];}if(!aid)throw new Error('AniList ID missing from ReAnime watch page '+id);return aid;});}
  function serversFor(aid,ep,id){return json(BASE+'/api/flix/'+aid+'/'+ep,{'Referer':watchUrl(id,ep)}).then(function(o){if(!o||!o.success||!Array.isArray(o.servers))throw new Error('ReAnime server API has no servers');return o.servers;});}
  function unwrapDirect(u,referer){if(/\.(?:m3u8|mp4)(?:[?#]|$)/i.test(u))return Promise.resolve(u);return http(u,{'Referer':referer||BASE+'/'}).then(function(r){var v=directMedia(r.text);if(!v)throw new Error('Embed did not expose a direct MP4/HLS stream');return v;});}
  function resolveServer(server){var embed=server.dataLink||server.url||'';if(!/^https?:\/\//i.test(embed))throw new Error('Server embed link missing');
    if(/flixcloud\.cc\/e\//i.test(embed))return http(embed,{'Referer':BASE+'/','Accept':'text/html,*/*'}).then(function(page){
      var fallback=directMedia(page.text);if(fallback)return{url:fallback,headers:{'Referer':FLIX+'/', 'User-Agent':UA}};
      var data=readEmbedPage(page.text);return json(FLIX+'/api/m3u8/'+encodeURIComponent(data.token),{'Referer':BASE+'/','Origin':FLIX}).then(function(tok){var url=decryptFlix(data,tok);if(!/^https?:\/\//i.test(url)||!/(?:\.m3u8|\.mp4)(?:[?#]|$)/i.test(url))throw new Error('FlixCloud result is not a media URL');return{url:url,headers:{'Referer':FLIX+'/', 'User-Agent':UA}};});
    });
    return unwrapDirect(embed,BASE+'/').then(function(url){return{url:url,headers:{'Referer':embed, 'User-Agent':UA}};});
  }
  function extractStreamUrl(episodeHref,lang){var info=parseWatchHref(episodeHref),want=/dub|english|\ben\b/i.test(String(lang||'sub'))?'dub':'sub';return fromWebPageId(info.id,info.ep).then(function(aid){return serversFor(aid,info.ep,info.id);}).then(function(servers){var options=servers.filter(function(s){return want==='dub'?/dub/i.test(s.dataType||''):/sub/i.test(s.dataType||'')&&!/dub/i.test(s.dataType||'');}).sort(function(a,b){return (a.serverName==='HD-2'?-1:0)-(b.serverName==='HD-2'?-1:0);});if(!options.length)throw new Error('No '+want+' servers for '+info.id+' episode '+info.ep);
    var failures=[];function tryNext(i){if(i>=options.length)throw new Error('No playable '+want+' stream for '+info.id+' ep '+info.ep+': '+failures.join(' | '));var s=options[i];return resolveServer(s).then(function(res){return mediaProbe(res.url,res.headers).then(function(){return{streams:[want+' '+(s.serverName||'Auto'),res.url],headers:res.headers,streamType:/\.mp4(?:[?#]|$)/i.test(res.url)?'mp4':'hls'};});}).catch(function(err){failures.push((s.serverName||'server')+': '+String(err.message||err).slice(0,120));return tryNext(i+1);});}return tryNext(0);
  });}
  globalThis.searchResults=searchResults;
  globalThis.extractDetails=extractDetails;
  globalThis.extractEpisodes=extractEpisodes;
  globalThis.extractStreamUrl=extractStreamUrl;
})();
